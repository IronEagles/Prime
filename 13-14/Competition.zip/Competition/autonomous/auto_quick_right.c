// Filename: auto_quick_right.c
// Description: Quickly score autonomous block in closest end basket and immediately turn left onto the ramp.
// Last Modified: 1/27/14

#include "configuration.h"
#include "helpers.c"

// GLOBALS
float currHeading = 0.0;

int direction = -1;

void initializeRobot()
{
	// Initialize encoders
  resetEncoders();

	// Spawn heading tracking thread
	StartTask(heading);
  wait1Msec(1000);

  return;
}

task main()
{
	initializeRobot();
	wait1Msec(2);
	waitForStart();

	// STEP 1: Move forward to the end basket
	while(nMotorEncoder[RightDrive] > direction * DISTANCE_TO_BASKET_FROM_INIT)
  {
		moveForward(direction * DEFAULT_TRAVEL_SPEED);
	}

	// STEP 2: Deploy auto-scoring arm
	servoTarget[autoServo] = AUTO_SCORING_ARM_DEPLOY_DISTANCE;
	wait1Msec(WAIT_BEFORE_RETRACT_AUTO_SCORE_ARM_MS);
	servoTarget[autoServo] = AUTO_SCORING_ARM_HOME;
	wait1Msec(500);

	while(nMotorEncoder[RightDrive] > direction * DISTANCE_FROM_BASKET_TO_TURN)
	{
		moveForward(direction * DEFAULT_TRAVEL_SPEED);
	}

	motor[LeftDrive] = DEFAULT_TRAVEL_SPEED;
	motor[RightDrive] = direction * DEFAULT_TRAVEL_SPEED;


	while(true)
	{
		wait1Msec(10);
		if (currHeading >= 45 && currHeading < 70) break;
	}
	halt();
	resetEncoders();
	wait1Msec(100);

		//STEP 7: Drive onto ramp
	while(nMotorEncoder[RightDrive] > -(4*360*3.5))
	{
		moveForward(-70);
	}
	halt();
	currHeading = 0.0;
	wait1Msec(100);

}
